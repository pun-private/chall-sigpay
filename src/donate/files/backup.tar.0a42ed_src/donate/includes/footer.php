         

        </main>

        <footer>
          <p>
            <span>&copy; <?= date("Y") ?></span>
            <a href="/">Retro.NFT</a>
            <span>//</span>
            <a href="CHANGELOG.md" target="_blank" rel="noopener">Changelog</a>
            <span>//</span>
            <a href="/files/terms_of_service" target="_blank" rel="noopener">Terms of service</a>
          </p>
        </footer>

      </div>
    </div>
  </body>
  <script src="./lib/script.js"></script>

</html>